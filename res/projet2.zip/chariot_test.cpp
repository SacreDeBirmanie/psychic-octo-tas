#include <iostream>
#include "produit.hpp"
#include "magasin.hpp"
#include "chariot.hpp"
#include "FPtas.hpp"
#include "FPstl.hpp"

using namespace std;

int main()
{
   Magasin m("entrepot_11.txt");

   Chariot</*À DÉFINIR*/> caddie(10.0);
  
   /* À COMPLÉTER */
   
   return 0;
}
